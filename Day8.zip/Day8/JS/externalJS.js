function AlertExternalJS() {
    document.body.style.backgroundColor="bisque";
    document.body.style.fontSize="2mm";
    document.body.style.fontFamily="xx-small";
    alert('Hello Guys');
    document.getElementById("btid1").style.backgroundColor="pink"
    document.getElementById("btid1").style.backgroundColor=prompt("Enter your color:")
}
function ConfirmExternalJS() {
    document.getElementById("btid2").style.backgroundColor="cornflowerblue"
    document.body.style.backgroundColor="pink";
    document.body.style.fontSize="2mm";
    document.body.style.fontFamily="xx-small";
    confirm('You want to continue?');
}
function PromptExternalJS() {
    document.getElementById("btid3").style.backgroundColor="bisque"
    document.body.style.backgroundColor="cornflowerblue";
    document.body.style.fontSize="2mm";
    document.body.style.fontFamily="xx-small";
    prompt('What is your name?');
}
function ChangeColorJS1() {
    document.body.style.backgroundColor=document.getElementById('colid1').value;
}
function ChangeColorJS2() {
    document.getElementById("divid").style.backgroundColor=document.getElementById('colid2').value;
}


function bt1() {
    var vname = prompt("Enter your name:");
    document.getElementById("sid").innerHTML=vname;
}
function bt2() {
    var fname = prompt("Enter First name:");
    var lname = prompt("Enter Last name:");
    document.getElementById("sid1").innerHTML=fname;
    document.getElementById("sid2").innerHTML=lname;
    alert(fname+" "+lname)
}

console.log("Good Morning!");

