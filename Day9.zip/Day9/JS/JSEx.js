function PromptExternalJS() {
    document.getElementById("mainimgid").src= "../Images/download (1).jpg";
}

function PromptExternalJS1() {
    document.getElementById("mainimgid").src= "../Images/download (2).jpg";
}

function PromptExternalJS2() {
    document.getElementById("mainimgid").src= "../Images/images (1).jpg";
}